Font that was used for the background of the preview:
http://www.dafont.com/venus-rising.font